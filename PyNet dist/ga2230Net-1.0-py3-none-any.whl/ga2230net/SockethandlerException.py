class SockethandlerException(Exception):
    """A general exception for socket handlers"""
    pass
